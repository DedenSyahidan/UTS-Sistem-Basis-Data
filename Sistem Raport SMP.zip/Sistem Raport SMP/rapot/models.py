from django.db import models

from siswa.models import Siswa

# Create your models here.
class Rapot(models.Model):
    siswa = models.ForeignKey(Siswa, on_delete=models.CASCADE)
    semester = models.IntegerField()
    tahun_ajaran = models.CharField(max_length=100)
    nilai_total = models.DecimalField(max_digits=5, decimal_places=2)
    catatan_guru = models.TextField()
    mata_pelajaran = models.TextField()