from django.db import models

# Create your models here.
class Siswa(models.Model):
    nama = models.CharField(max_length=100, null=True)
    nis = models.CharField(max_length=10, null=True, unique=True)
    tanggal_lahir = models.DateField(null=True)
    alamat = models.TextField(null=True)

class Kehadiran(models.Model):
    siswa = models.ForeignKey(Siswa, on_delete=models.CASCADE)
    tanggal = models.DateField()
    status = models.CharField(max_length=10, choices=[('Hadir', 'Hadir'), ('Alpa', 'Alpa'), ('Izin', 'Izin'), ('Sakit', 'Sakit')])

class Kelas(models.Model):
    ruangan_kelas = models.TextField(null=True) # type: ignore