from django.contrib import admin
from siswa.models import Siswa, Kehadiran, Kelas
from nilai.models import Nilai, MataPelajaran
from rapot.models import Rapot 
from Guru.models import Guru

# Register your models here.
# ini bagian Siswa
admin.site.register(Siswa)
admin.site.register(Kehadiran)

admin.site.register(Nilai)
admin.site.register(Guru)
admin.site.register(MataPelajaran)

admin.site.register(Rapot)
admin.site.register(Kelas)
