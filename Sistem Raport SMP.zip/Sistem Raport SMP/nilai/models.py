from django.db import models
from siswa.models import Siswa

# Create your models here.
class MataPelajaran(models.Model):
    nama = models.CharField(max_length=50)
    deskripsi = models.TextField(null=True)

class Nilai(models.Model):
    siswa = models.ForeignKey(Siswa, on_delete=models.CASCADE)
    mata_pelajaran = models.ForeignKey(MataPelajaran, on_delete=models.CASCADE)
    nilai_uh = models.IntegerField(null=True)
    nilai_uts = models.IntegerField(null=True)
    nilai_uas = models.IntegerField(null=True)
    tanggal_input = models.DateField(auto_now_add=True)