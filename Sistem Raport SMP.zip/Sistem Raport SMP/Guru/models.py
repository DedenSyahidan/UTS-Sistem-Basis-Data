from django.db import models

from nilai.models import MataPelajaran
from siswa.models import Siswa

# Create your models here.
class Guru(models.Model):
    siswa = models.ForeignKey(Siswa, on_delete=models.CASCADE)
    nip = models.CharField(max_length=18, unique=True)
    mata_pelajaran = models.ForeignKey(MataPelajaran, on_delete=models.CASCADE)
    email = models.EmailField(null=True)